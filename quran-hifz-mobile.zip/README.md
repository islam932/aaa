# حفظ القرآن – نسخة الموبايل

1. اعمل Repository جديد على GitHub.
2. افتح الـ zip وارفع **محتوياته** كلها على جذر الـ repo (مهم: فولدر `.github` لازم يترفع كمان. لو ماترفعش، اعمله من GitHub: Add file ← Create new file واكتب الاسم `.github/workflows/build-apk.yml` والصق محتوى الملف).
3. افتح تبويب **Actions** ← **Build APK** (أو شغّله يدوي بـ Run workflow) واستنى 3–6 دقايق.
4. الـ APK هتلاقيه في **Artifacts** (اسمه QuranHifz-apk) أو في **Releases** مباشرة.

التعديل على الواجهة: `app/src/main/assets/index.html`
